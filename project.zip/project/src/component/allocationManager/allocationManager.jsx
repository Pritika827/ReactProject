import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import React from "react";

const AllocationManager = () => {
    const Base_URL = "http://localhost:8087/AMDetails/getAMById";
 
    const [allocationManager, getAllocationManager] = useState({});
    const loadAllocationManager = (caseId) => {

        axios.get(Base_URL +""+caseId).then(response => {
            console.log("DATA", response.data);
            getAllocationManager(response.data);
        }).catch(err => {
            console.log("ERROR", err.message)
        });
    }

    const { caseId } = useParams();
    useEffect(() => {
        loadAllocationManager(caseId)
    });
    let result = <tr key={allocationManager.caseId}>
        <td>{allocationManager.caseStatus}</td>
        <td>{allocationManager.caseAssignedDate}</td>
        <td>{allocationManager.assignee}</td>
    </tr>
    let divstyle = {        
        padding: 40
        }
    return (
        <div style={divstyle}>
            <table border={1}>
            <thead>
                <tr>
                    <th>caseStatus</th>
                    <th>caseAssignedDate</th>
                    <th>assignee</th>
                    
                </tr>
            </thead>
            <tbody>
                {
                    result
                }
            </tbody>
        </table>

        </div>
    );
}
export default AllocationManager;