import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";

const AllocationManagers = () => {
    const Base_URL = "http://localhost:8087/AMDetails/AMList";
    //const Base_URL = "https://jsonplaceholder.typicode.com/";

    const [allocationManagers, getAllocationManagers] = useState([]);
    const loadAllocationManagers = () => {

        axios.get(Base_URL).then(response => {
            console.log("DATA", response.data);
            getAllocationManagers(response.data);
        }).catch(err => {
            console.log("ERROR", err.message)
        });
    }

    const { caseId } = useParams();
    useEffect(() => {
        loadAllocationManagers(caseId)
    });
    let result = allocationManagers.map(am => <tr key={am.caseId}>
        <td>{am.caseId}</td>
        <td>{am.caseStatus}</td>
        <td>{am.caseAssignedDate}</td>
        <td>{am.assignee}</td>
        <td><Link to={''+am.caseId} > show details</Link></td>

    </tr>)

let divstyle = {        
    padding: 40
    }
    return (
        <div style={divstyle}>
            <table border={1} cellPadding="2" cellSpacing="5">
            <thead>
                <tr>
                    <th>caseId</th>
                    <th>caseStatus</th>
                    <th>caseAssignedDate</th>
                    <th>assignee</th>
                    <th>details</th>
                </tr>
            </thead>
            <tbody>
                {
                    result
                }
            </tbody>
        </table>

        </div>
    );
}
export default AllocationManagers;