import { Link } from "react-router-dom";


const Header = () => {

    let fontstyle = {        
    fontFamily: "Arial"
    }
    return(
        <div>
            <h2 className="heading" style={fontstyle} > ** Project ** </h2>
            <hr />
            <Link to="/">Allocation Manager</Link>|
            <Link to="/demo">Demo</Link>|
            
        </div>
    );
}
export default Header;