class Pritika{
    render(){
        let langs=["a","b","c"]
        return(
            <div>
                {langs.map(it=><p>{it}</p>)}
            </div>
        )
    }
}
export default Pritika;