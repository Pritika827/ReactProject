
import { BrowserRouter, Route, Routes } from "react-router-dom";
import AllocationManager from "./component/allocationManager/allocationManager";
import AllocationManagers from "./component/allocationManager/allocationManagers";
import Demo from "./component/demo/demo";
import Header from "./component/header/header";


function App() {
  return (
    <div className="App">
      
      <BrowserRouter>
      <Header />
        <Routes>
        <Route path="/demo" element={<Demo/>}></Route>

          <Route path="/" element={<AllocationManagers />}></Route>
          <Route path="/:caseId" element={<AllocationManager />}></Route>
        </Routes>
      </BrowserRouter>

    </div>
  );
}

export default App;
